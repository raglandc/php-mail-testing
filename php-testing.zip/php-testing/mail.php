<?php 
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1 );
error_reporting(E_ALL);


$name = $_POST["name"];
$email = $_POST["email"];
$message = $_POST["message"];

$from = "chrisragland97@gmail.com";
$to = 'Chrisragland97@gmail.com';

$host = "ssl://smtp.gmail.com";
$port = "587";
$username = 'chrisragland97@gmail.com';
$password = 'Thisisafake@1';

$subject = "test";
$body = "test";

$headers = 'From:'. $email;
// $smtp = Mail::factory('smtp',
//   array ('host' => $host,
//     'port' => $port,
//     'auth' => true,
//     'username' => $username,
//     'password' => $password));

// $mail = $smtp->send($to, $headers, $body);

// if (PEAR::isError($mail)) {
//   echo($mail->getMessage());
// } else {
//   echo("Message successfully sent!\n");
// }
mail( $to,  $subject,  $message, $headers,  $additional = ""); 


if(mail( $to,  $subject,  $message, $headers,  $additional = "")) {
   echo "message sent yayyyy" ;
};

if(!mail( $to,  $subject,  $message, $headers,  $additional = "")) {
    echo "didnt work 😭";
}

?>